
import 'package:flutter/material.dart';

void main() {
  runApp(const HuseniVasilaApp());
}

const Color primaryColor = Color(0xFF6653E8);
const Color backgroundColor = Color(0xFFF5F6FA);

class HuseniVasilaApp extends StatelessWidget {
  const HuseniVasilaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Huseni Vasila',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: backgroundColor,
        colorScheme: ColorScheme.fromSeed(seedColor: primaryColor),
      ),
      home: const AppShell(),
    );
  }
}

class Worker {
  final String name;
  final String role;

  const Worker(this.name, this.role);
}

const List<Worker> workers = [
  Worker('Afzal Hundada', 'Mason'),
  Worker('Arif chabba', 'Mason'),
  Worker('Ayaan Subhaniya', 'Mason'),
  Worker('Bhayani Ajijj', 'Mason'),
  Worker('Dadu Chabba', 'Helper'),
  Worker('Gafur Chamadiya', 'Helper'),
  Worker('Hajar baai', 'Labour'),
  Worker('Husein Godivara', 'Helper'),
  Worker('Ibrahim M Shodha', 'Mason'),
  Worker('Nadim Alvani', 'Mason'),
  Worker('Nashim', 'Labour'),
  Worker('Navaz Manek', 'Helper'),
  Worker('Nawaz bhukeda', 'Helper'),
  Worker('Nawaz Sameja', 'Helper'),
  Worker('Sahil', 'Mason'),
  Worker('Salman', 'Helper'),
  Worker('Shahid', 'Labour'),
  Worker('Yusuf', 'Mason'),
];

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int selectedIndex = 0;

  final List<Widget> pages = const [
    DashboardPage(),
    AttendancePage(),
    WorkforcePage(),
    PettyCashPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[selectedIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (index) {
          setState(() => selectedIndex = index);
        },
        indicatorColor: Colors.transparent,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_pin_outlined),
            selectedIcon: Icon(Icons.person_pin),
            label: 'Attendance',
          ),
          NavigationDestination(
            icon: Icon(Icons.groups_outlined),
            selectedIcon: Icon(Icons.groups),
            label: 'Workforce',
          ),
          NavigationDestination(
            icon: Icon(Icons.account_balance_wallet_outlined),
            selectedIcon: Icon(Icons.account_balance_wallet),
            label: 'PettyCash',
          ),
          NavigationDestination(
            icon: Icon(Icons.account_circle_outlined),
            selectedIcon: Icon(Icons.account_circle),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

Widget pageHeader(
  String title, {
  Widget? right,
  double height = 136,
}) {
  return Container(
    height: height,
    width: double.infinity,
    padding: const EdgeInsets.fromLTRB(22, 48, 22, 14),
    decoration: const BoxDecoration(
      color: primaryColor,
      borderRadius: BorderRadius.vertical(
        bottom: Radius.circular(28),
      ),
    ),
    child: Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        right ??
            const Icon(
              Icons.headset_mic_outlined,
              color: Colors.white,
            ),
      ],
    ),
  );
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    final features = [
      ['Worker Dashboard', Icons.person_add_alt_1, 0xFFF1C9B7],
      ['Material', Icons.local_shipping_outlined, 0xFFCDE7F5],
      ['My Usage', Icons.donut_large, 0xFFC9C1F0],
      ['DPR', Icons.receipt_long, 0xFFB8E9E3],
      ['Accounting', Icons.receipt, 0xFFBCE7D3],
      ['Reports', Icons.bar_chart, 0xFFF3B9E8],
      ['Leave Approvals', Icons.fact_check_outlined, 0xFFC9C1F0],
      ['Petty Cash Balance', Icons.account_balance_wallet, 0xFFF5E9A7],
    ];

    return SafeArea(
      top: false,
      child: Column(
        children: [
          pageHeader('Dashboard'),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(22),
              children: [
                Row(
                  children: const [
                    Icon(Icons.explore),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Explore Features',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    Text(
                      'View All ›',
                      style: TextStyle(
                        color: primaryColor,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    _featureCard(
                      'Lens App',
                      'Face recognition\nattendance',
                      Icons.face_retouching_natural,
                      0xFFB8EBCF,
                    ),
                    const SizedBox(width: 14),
                    _featureCard(
                      'View Live Location',
                      'Track workers in real-\ntime',
                      Icons.location_pin,
                      0xFFC5D2F7,
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: primaryColor),
                  ),
                  child: const Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: Color(0xFFE9E6FF),
                        child: Icon(
                          Icons.workspace_premium,
                          color: primaryColor,
                        ),
                      ),
                      SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Current Plan: Starter',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            Text(
                              'You have access to premium features',
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.black54,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: features.length,
                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: .92,
                  ),
                  itemBuilder: (context, index) {
                    final item = features[index];
                    final String title = item[0] as String;
                    final IconData icon = item[1] as IconData;
                    final int colorValue = item[2] as int;

                    return Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Color(colorValue),
                        borderRadius: BorderRadius.circular(22),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(icon, size: 31),
                          const Spacer(),
                          Text(
                            title,
                            style: const TextStyle(
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: const Color(0xFFDDEEFF),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Row(
                    children: [
                      Icon(
                        Icons.business_center,
                        color: primaryColor,
                        size: 30,
                      ),
                      SizedBox(width: 15),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Real Estate CRM-Poladio',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            Text(
                              'Power up your property sales & lead management',
                              style: TextStyle(
                                color: Colors.black54,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Icon(Icons.chevron_right),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static Widget _featureCard(
    String title,
    String subtitle,
    IconData icon,
    int colorValue,
  ) {
    return Expanded(
      child: Container(
        height: 116,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Color(colorValue),
          borderRadius: BorderRadius.circular(22),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: primaryColor),
            Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 16,
              ),
            ),
            Text(
              subtitle,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                color: Colors.black54,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AttendancePage extends StatelessWidget {
  const AttendancePage({super.key});

  @override
  Widget build(BuildContext context) {
    final mason = workers.where((w) => w.role == 'Mason').toList();
    final helper = workers.where((w) => w.role == 'Helper').toList();
    final labour = workers.where((w) => w.role == 'Labour').toList();

    return SafeArea(
      top: false,
      child: Column(
        children: [
          Container(
            height: 136,
            color: primaryColor,
            padding: const EdgeInsets.fromLTRB(16, 48, 16, 10),
            child: Column(
              children: const [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Current Site\nDefault Site  ▾',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    Icon(Icons.qr_code_scanner, color: Colors.white),
                    SizedBox(width: 18),
                    Icon(Icons.search, color: Colors.white),
                    SizedBox(width: 18),
                    Icon(Icons.more_vert, color: Colors.white),
                  ],
                ),
                SizedBox(height: 10),
                Text(
                  '‹     Tue  11 Aug      Wed  12 Aug      Thu  13 Aug     ›',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              children: [
                _workerGroup('Mason', mason),
                _workerGroup('Helper', helper),
                _workerGroup('Labour', labour),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static Widget _workerGroup(String title, List<Worker> list) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(10),
          color: const Color(0xFFF0F1F5),
          child: Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 17,
            ),
          ),
        ),
        ...list.map(
          (worker) => Container(
            padding: const EdgeInsets.fromLTRB(16, 16, 12, 13),
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(color: Color(0xFFE0E0E0)),
              ),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        worker.name,
                        style: const TextStyle(
                          color: primaryColor,
                          fontWeight: FontWeight.w800,
                          fontSize: 17,
                        ),
                      ),
                    ),
                    _statusBadge('CARD'),
                    const SizedBox(width: 15),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 9,
                      ),
                      decoration: BoxDecoration(
                        color: primaryColor,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Text(
                        'Pay',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    const Icon(Icons.more_vert),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    _statusBadge('IN'),
                    _statusBadge('OUT'),
                    const Spacer(),
                    ...['P', 'P+P', 'P+½', 'A', 'H', 'OT']
                        .map(_statusBadge),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  static Widget _statusBadge(String text) {
    return Container(
      margin: const EdgeInsets.only(right: 7),
      padding: const EdgeInsets.symmetric(
        horizontal: 11,
        vertical: 6,
      ),
      decoration: BoxDecoration(
        border: Border.all(color: const Color(0xFFE0E0E0)),
        borderRadius: BorderRadius.circular(11),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: primaryColor,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class WorkforcePage extends StatelessWidget {
  const WorkforcePage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Column(
        children: [
          pageHeader(
            'Manage Workforce',
            right: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.search, color: Colors.white),
                SizedBox(width: 18),
                Icon(Icons.more_vert, color: Colors.white),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(16),
            child: Row(
              children: [
                Text(
                  'Active: 18',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  '  |  Inactive: 0',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Spacer(),
                Icon(Icons.filter_alt_outlined, color: primaryColor),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: workers.length,
              itemBuilder: (context, index) {
                final worker = workers[index];
                return ListTile(
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 22,
                    vertical: 5,
                  ),
                  leading: const CircleAvatar(
                    radius: 27,
                    backgroundColor: Color(0xFFD7C8F8),
                    child: Icon(Icons.person, color: Colors.white),
                  ),
                  title: Text(
                    worker.name,
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 17,
                    ),
                  ),
                  subtitle: Text(
                    '${worker.role} / Default Site',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  trailing: const Icon(Icons.more_vert),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class PettyCashPage extends StatefulWidget {
  const PettyCashPage({super.key});

  @override
  State<PettyCashPage> createState() => _PettyCashPageState();
}

class _PettyCashPageState extends State<PettyCashPage> {
  final List<String> entries = [];

  void addPettyCash() {
    final descriptionController = TextEditingController();
    final amountController = TextEditingController();

    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Add Petty Cash'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: descriptionController,
                decoration: const InputDecoration(
                  labelText: 'Description',
                ),
              ),
              TextField(
                controller: amountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Amount',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                if (descriptionController.text.trim().isNotEmpty) {
                  setState(() {
                    entries.add(
                      '${descriptionController.text.trim()} — ₹${amountController.text.trim()}',
                    );
                  });
                }
                Navigator.pop(dialogContext);
              },
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Column(
        children: [
          Container(
            height: 136,
            color: primaryColor,
            padding: const EdgeInsets.fromLTRB(22, 48, 22, 15),
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    'Pettycash account\nDefault Account  ▾',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Text(
                    '₹0.0',
                    style: TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                const Icon(Icons.settings, color: Colors.white),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(18),
            child: Row(
              children: [
                Text(
                  'No Filters Applied',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Spacer(),
                Icon(Icons.filter_list),
                SizedBox(width: 20),
                Icon(Icons.sort),
              ],
            ),
          ),
          Expanded(
            child: entries.isEmpty
                ? const Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'No items found',
                          style: TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        Text(
                          'The list is currently empty.',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView(
                    children: entries
                        .map(
                          (entry) => ListTile(
                            title: Text(
                              entry,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        )
                        .toList(),
                  ),
          ),
          Align(
            alignment: Alignment.bottomRight,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: FloatingActionButton(
                backgroundColor: primaryColor,
                onPressed: addPettyCash,
                child: const Icon(Icons.add, color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Column(
        children: [
          Container(
            height: 285,
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(22, 58, 22, 20),
            decoration: const BoxDecoration(
              color: primaryColor,
              borderRadius: BorderRadius.vertical(
                bottom: Radius.circular(30),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Profile',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 25,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 24),
                const Row(
                  children: [
                    CircleAvatar(
                      radius: 48,
                      backgroundColor: Color(0xFFD8C8F4),
                      child: Icon(
                        Icons.person,
                        size: 55,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Huseni Vasila',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          Text(
                            'husenivasila92@gmail.com ✓',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text(
                            '917041808810 ✓',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text(
                            'v1.0.0',
                            style: TextStyle(color: Colors.white70),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(22),
              children: [
                _settingsSection(
                  'ACCOUNT SETTINGS',
                  [
                    'Edit Profile|edit your company & gst details',
                    'Master App Data Setup|sites, category, material, pettycash, etc',
                    'Settings & more|language, menu, plan, invoices, etc',
                  ],
                ),
                _settingsSection(
                  'EXPERIENCE & GROWTH',
                  [
                    'How Features Work|Videos to learn how to use the app',
                    'Upcoming Feature|Features and updates coming soon',
                    'Refer a friend|Earn rewards by sharing with friends',
                  ],
                ),
                _settingsSection(
                  'SUPPORT & COMMUNITY',
                  [
                    'Join Our Community|join whatsapp channel',
                    'Rate 5 stars|Tell us how we are doing',
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static Widget _settingsSection(String heading, List<String> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 6, bottom: 10),
          child: Text(
            heading,
            style: const TextStyle(
              letterSpacing: 1.5,
              color: Colors.black54,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            children: items.map((item) {
              final parts = item.split('|');
              return ListTile(
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 6,
                ),
                leading: const CircleAvatar(
                  backgroundColor: Color(0xFFEDE8FF),
                  child: Icon(Icons.settings, color: primaryColor),
                ),
                title: Text(
                  parts[0],
                  style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 17,
                  ),
                ),
                subtitle: Text(
                  parts.length > 1 ? parts[1] : '',
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    color: Colors.black54,
                  ),
                ),
                trailing: const Icon(Icons.chevron_right),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 25),
      ],
    );
  }
}
