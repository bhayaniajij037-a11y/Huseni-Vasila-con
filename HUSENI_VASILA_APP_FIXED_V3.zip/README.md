# Huseni Vasila
UI recreated from the supplied app screenshots. Run `flutter pub get` then `flutter build apk --release`.
