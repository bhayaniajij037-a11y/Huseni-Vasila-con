import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:intl/intl.dart';

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Huseni Vasila',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.red),
    home: const Login(),
  );
}

class DB {
  static Future<List<Map<String, dynamic>>> get(String key) async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString(key);
    if (s == null) return [];
    return List<Map<String, dynamic>>.from(
      (jsonDecode(s) as List).map((e) => Map<String, dynamic>.from(e)),
    );
  }

  static Future<void> put(String key, List<Map<String, dynamic>> v) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(key, jsonEncode(v));
  }
}

class Login extends StatefulWidget {
  const Login({super.key});
  @override State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  bool worker = false;
  final phone = TextEditingController(), pin = TextEditingController();

  @override
  Widget build(BuildContext c) => Scaffold(
    body: Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(22),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(children: [
              const Icon(Icons.construction, size: 65, color: Colors.red),
              const Text('HUSENI VASILA',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              const Text('Contractor • Hajri • Site Manager'),
              const SizedBox(height: 18),
              SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(value: false, label: Text('Admin')),
                  ButtonSegment(value: true, label: Text('Worker')),
                ],
                selected: {worker},
                onSelectionChanged: (s) => setState(() => worker = s.first),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                    labelText: 'Mobile Number',
                    border: OutlineInputBorder()),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: pin,
                obscureText: true,
                decoration: const InputDecoration(
                    labelText: 'PIN', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 15),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () => Navigator.pushReplacement(
                    c,
                    MaterialPageRoute(
                        builder: (_) => worker ? const Worker() : const Admin()),
                  ),
                  child: Text(worker ? 'Worker Login' : 'Admin Login'),
                ),
              ),
              const SizedBox(height: 8),
              const Text('Demo login • Data is saved locally on this device',
                  style: TextStyle(color: Colors.grey)),
            ]),
          ),
        ),
      ),
    ),
  );
}

class Admin extends StatefulWidget {
  const Admin({super.key});
  @override State<Admin> createState() => _AdminState();
}

class _AdminState extends State<Admin> {
  int tab = 0;

  void openTab(int i) => setState(() => tab = i);

  @override
  Widget build(BuildContext c) {
    final pages = [
      Dashboard(onOpenTab: openTab),
      const Attendance(),
      const Staff(),
      const Sites(),
      const MaterialEntry(),
      const Payments(),
      const Support(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('HUSENI VASILA'),
        backgroundColor: Colors.red,
        foregroundColor: Colors.white,
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: openTab,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.calendar_month), label: 'Hajri'),
          NavigationDestination(icon: Icon(Icons.people), label: 'Staff'),
          NavigationDestination(icon: Icon(Icons.location_city), label: 'Site'),
          NavigationDestination(icon: Icon(Icons.inventory), label: 'Material'),
          NavigationDestination(icon: Icon(Icons.payments), label: 'Payment'),
          NavigationDestination(icon: Icon(Icons.support_agent), label: 'Support'),
        ],
      ),
    );
  }
}

class Dashboard extends StatelessWidget {
  final void Function(int) onOpenTab;
  const Dashboard({required this.onOpenTab, super.key});

  void openSpecial(BuildContext c, String title) {
    Navigator.push(c, MaterialPageRoute(builder: (_) => SimplePage(title: title)));
  }

  @override
  Widget build(BuildContext c) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('Dashboard',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
      const SizedBox(height: 5),
      Text(DateFormat('dd MMMM yyyy').format(DateTime.now())),
      const SizedBox(height: 18),
      Wrap(
        spacing: 12,
        runSpacing: 12,
        children: [
          InfoCard('👷', 'Staff', () => onOpenTab(2)),
          InfoCard('📅', 'Hajri Book', () => onOpenTab(1)),
          InfoCard('🏗️', 'Sites', () => onOpenTab(3)),
          InfoCard('📦', 'Material', () => onOpenTab(4)),
          InfoCard('💰', 'Payment', () => onOpenTab(5)),
          InfoCard('📄', 'Reports', () => openSpecial(c, 'Reports')),
          InfoCard('🎥', 'Video Upload', () => openSpecial(c, 'Video Upload')),
          InfoCard('🆘', 'Support', () => onOpenTab(6)),
        ],
      ),
      const SizedBox(height: 18),
      const Card(
        child: ListTile(
          leading: Icon(Icons.sync, color: Colors.green),
          title: Text('Worker → Admin Sync'),
          subtitle: Text('Entries are saved locally. Cloud sync can be connected later.'),
        ),
      ),
    ],
  );
}

class InfoCard extends StatelessWidget {
  final String icon, title;
  final VoidCallback onTap;
  const InfoCard(this.icon, this.title, this.onTap, {super.key});

  @override
  Widget build(BuildContext c) => SizedBox(
    width: 160,
    height: 105,
    child: Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(icon, style: const TextStyle(fontSize: 28)),
              const SizedBox(height: 4),
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    ),
  );
}

class Attendance extends StatefulWidget {
  const Attendance({super.key});
  @override State<Attendance> createState() => _AttendanceState();
}

class _AttendanceState extends State<Attendance> {
  final names = ['Raju Mistri', 'Salim', 'Imran', 'Arif', 'Ramesh'];
  final Map<String, String> today = {};
  bool loading = true;

  String get dateKey => DateFormat('yyyy-MM-dd').format(DateTime.now());

  @override
  void initState() {
    super.initState();
    loadToday();
  }

  Future<void> loadToday() async {
    final a = await DB.get('attendance');
    for (final x in a) {
      if (x['date'] == dateKey && x['worker'] != null) {
        today[x['worker'].toString()] = x['status'].toString();
      }
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> setStatus(String worker, String status) async {
    final a = await DB.get('attendance');
    a.removeWhere((x) => x['date'] == dateKey && x['worker'] == worker);
    a.add({
      'date': dateKey,
      'worker': worker,
      'status': status,
      'time': DateTime.now().toIso8601String(),
    });
    await DB.put('attendance', a);
    if (mounted) {
      setState(() => today[worker] = status);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$worker: $status saved')),
      );
    }
  }

  Future<void> editStatus(String worker) async {
    String selected = today[worker] ?? '';
    final result = await showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text('Edit Hajri • $worker'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: ['P', 'A', 'H'].map((s) => RadioListTile<String>(
            value: s,
            groupValue: selected,
            title: Text(s == 'P'
                ? 'Present'
                : s == 'A'
                    ? 'Absent'
                    : 'Half Day'),
            onChanged: (v) {
              if (v != null) Navigator.pop(d, v);
            },
          )).toList(),
        ),
      ),
    );
    if (result != null) await setStatus(worker, result);
  }

  @override
  Widget build(BuildContext c) {
    if (loading) return const Center(child: CircularProgressIndicator());
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        const Text('Hajri Book',
            style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
        Text(DateFormat('dd MMMM yyyy').format(DateTime.now())),
        const SizedBox(height: 5),
        const Text('P = Present   •   A = Absent   •   H = Half Day',
            style: TextStyle(color: Colors.grey)),
        const SizedBox(height: 12),
        Card(
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columnSpacing: 18,
              columns: const [
                DataColumn(label: Text('Worker')),
                DataColumn(label: Text('P')),
                DataColumn(label: Text('A')),
                DataColumn(label: Text('H')),
                DataColumn(label: Text('Edit')),
              ],
              rows: names.map((n) {
                return DataRow(cells: [
                  DataCell(Text(n)),
                  ...['P', 'A', 'H'].map((s) => DataCell(
                    IconButton(
                      tooltip: s == 'P'
                          ? 'Present'
                          : s == 'A'
                              ? 'Absent'
                              : 'Half Day',
                      onPressed: () => setStatus(n, s),
                      icon: CircleAvatar(
                        radius: 16,
                        backgroundColor: today[n] == s
                            ? Colors.red
                            : Colors.grey.shade200,
                        child: Text(s,
                            style: TextStyle(
                                color: today[n] == s
                                    ? Colors.white
                                    : Colors.black,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                  )),
                  DataCell(IconButton(
                    tooltip: 'Edit Hajri',
                    icon: const Icon(Icons.edit, color: Colors.red),
                    onPressed: () => editStatus(n),
                  )),
                ]);
              }).toList(),
            ),
          ),
        ),
      ],
    );
  }
}

class Staff extends StatefulWidget {
  const Staff({super.key});
  @override State<Staff> createState() => _StaffState();
}

class _StaffState extends State<Staff> {
  final n = TextEditingController(), m = TextEditingController(),
      r = TextEditingController(), rate = TextEditingController();
  List<Map<String, dynamic>> list = [];

  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    list = await DB.get('staff');
    if (mounted) setState(() {});
  }
  Future<void> add() async {
    if (n.text.trim().isEmpty) return;
    list.add({'name': n.text.trim(), 'mobile': m.text.trim(),
      'role': r.text.trim(), 'rate': rate.text.trim()});
    await DB.put('staff', list);
    n.clear(); m.clear(); r.clear(); rate.clear();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext c) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('Staff Entry',
          style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
      for (final x in [n, m, r, rate])
        Padding(
          padding: const EdgeInsets.only(top: 9),
          child: TextField(
            controller: x,
            keyboardType: x == rate ? TextInputType.number : TextInputType.text,
            decoration: InputDecoration(
              labelText: x == n
                  ? 'Worker Name'
                  : x == m
                      ? 'Mobile Number'
                      : x == r
                          ? 'Role'
                          : 'Daily Rate ₹',
              border: const OutlineInputBorder(),
            ),
          ),
        ),
      const SizedBox(height: 10),
      FilledButton.icon(onPressed: add, icon: const Icon(Icons.add),
          label: const Text('Add Staff')),
      ...list.map((x) => Card(
        child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.person)),
          title: Text(x['name']),
          subtitle: Text('${x['role']} • ₹${x['rate']} • ${x['mobile']}'),
        ),
      )),
    ],
  );
}

class Sites extends StatelessWidget {
  const Sites({super.key});
  @override Widget build(BuildContext c) =>
      const Entry(title: 'Site Entry', fields: ['Site Name', 'Customer Name', 'Address', 'Work Status']);
}

class MaterialEntry extends StatelessWidget {
  const MaterialEntry({super.key});
  @override Widget build(BuildContext c) =>
      const Entry(title: 'Material Entry', fields: ['Material Name', 'Quantity', 'Unit', 'Rate ₹', 'Site']);
}

class Payments extends StatelessWidget {
  const Payments({super.key});
  @override Widget build(BuildContext c) =>
      const Entry(title: 'Payment Entry', fields: ['Worker', 'Amount ₹', 'Date', 'Note']);
}

class Entry extends StatefulWidget {
  final String title;
  final List<String> fields;
  const Entry({required this.title, required this.fields, super.key});
  @override State<Entry> createState() => _EntryState();
}

class _EntryState extends State<Entry> {
  late List<TextEditingController> cs;
  @override void initState() {
    super.initState();
    cs = widget.fields.map((_) => TextEditingController()).toList();
  }
  @override void dispose() {
    for (final x in cs) x.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext c) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Text(widget.title,
          style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
      ...List.generate(widget.fields.length, (i) => Padding(
        padding: const EdgeInsets.only(top: 10),
        child: TextField(
          controller: cs[i],
          decoration: InputDecoration(
              labelText: widget.fields[i], border: const OutlineInputBorder()),
        ),
      )),
      const SizedBox(height: 12),
      FilledButton(
        onPressed: () => ScaffoldMessenger.of(c).showSnackBar(
            const SnackBar(content: Text('Entry saved.'))),
        child: const Text('Save Entry'),
      ),
    ],
  );
}

class Support extends StatelessWidget {
  const Support({super.key});
  @override
  Widget build(BuildContext c) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('Support',
          style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
      const SizedBox(height: 15),
      Card(
        child: ListTile(
          onTap: () => showDialog(
            context: c,
            builder: (_) => const AlertDialog(
              title: Text('Help & Support'),
              content: Text('Contact your app administrator for assistance.'),
            ),
          ),
          leading: const Icon(Icons.help),
          title: const Text('Help & Support'),
          subtitle: const Text('Tap to open help'),
          trailing: const Icon(Icons.chevron_right),
        ),
      ),
      Card(
        child: ListTile(
          onTap: () => Navigator.push(c,
              MaterialPageRoute(builder: (_) => const VideoUploadPage())),
          leading: const Icon(Icons.video_library),
          title: const Text('Video Upload'),
          subtitle: const Text('Tap to open video upload'),
          trailing: const Icon(Icons.chevron_right),
        ),
      ),
    ],
  );
}

class SimplePage extends StatelessWidget {
  final String title;
  const SimplePage({required this.title, super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: Text(title), backgroundColor: Colors.red,
        foregroundColor: Colors.white),
    body: Center(
      child: Card(
        margin: const EdgeInsets.all(24),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(title == 'Reports' ? Icons.description : Icons.video_library,
                size: 60, color: Colors.red),
            const SizedBox(height: 12),
            Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('This section is ready for the next backend step.'),
          ]),
        ),
      ),
    ),
  );
}

class ReportsPage extends StatelessWidget {
  const ReportsPage({super.key});
  @override Widget build(BuildContext c) => const SimplePage(title: 'Reports');
}

class VideoUploadPage extends StatelessWidget {
  const VideoUploadPage({super.key});
  @override Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Video Upload'), backgroundColor: Colors.red,
        foregroundColor: Colors.white),
    body: Center(
      child: FilledButton.icon(
        onPressed: () => ScaffoldMessenger.of(c).showSnackBar(
            const SnackBar(content: Text('Video picker/backend will be connected next.'))),
        icon: const Icon(Icons.upload),
        label: const Text('Select Video'),
      ),
    ),
  );
}

class Worker extends StatefulWidget {
  const Worker({super.key});
  @override State<Worker> createState() => _WorkerState();
}

class _WorkerState extends State<Worker> {
  String s = '-';
  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Worker App'), backgroundColor: Colors.red,
        foregroundColor: Colors.white),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('My Hajri', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
      Text(DateFormat('dd MMMM yyyy').format(DateTime.now())),
      const SizedBox(height: 18),
      Row(children: ['P', 'H', 'A'].map((x) => Expanded(
        child: Padding(
          padding: const EdgeInsets.all(4),
          child: FilledButton(
            onPressed: () => setState(() => s = x),
            child: Text(x, style: const TextStyle(fontSize: 20)),
          ),
        ),
      )).toList()),
      const SizedBox(height: 14),
      Card(child: ListTile(
        leading: const Icon(Icons.check_circle, color: Colors.green),
        title: Text('Today: $s'),
        subtitle: const Text('Worker entry is saved locally; connect cloud backend for live Admin sync.'),
      )),
      const SizedBox(height: 10),
      const Card(child: ListTile(leading: Icon(Icons.location_city), title: Text('Site Entry'))),
      const Card(child: ListTile(leading: Icon(Icons.inventory), title: Text('Material Entry'))),
      const Card(child: ListTile(leading: Icon(Icons.payments), title: Text('Payment / Advance'))),
    ]),
  );
}
