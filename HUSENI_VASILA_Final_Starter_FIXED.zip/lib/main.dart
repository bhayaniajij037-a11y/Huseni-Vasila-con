import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:intl/intl.dart';

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
    debugShowCheckedModeBanner:false,
    title:'Huseni Vasila',
    theme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.red),
    home:const Login(),
  );
}

class DB {
  static Future<List<Map<String,dynamic>>> get(String key) async {
    final p=await SharedPreferences.getInstance();
    final s=p.getString(key);
    if(s==null)return [];
    return List<Map<String,dynamic>>.from((jsonDecode(s) as List).map((e)=>Map<String,dynamic>.from(e)));
  }
  static Future<void> put(String key,List<Map<String,dynamic>> v) async {
    final p=await SharedPreferences.getInstance();
    await p.setString(key,jsonEncode(v));
  }
}

class Login extends StatefulWidget { const Login({super.key}); @override State<Login> createState()=>_LoginState(); }
class _LoginState extends State<Login>{
  bool worker=false;
  final phone=TextEditingController(),pin=TextEditingController();
  @override Widget build(BuildContext c)=>Scaffold(
    body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(22),child:Card(
      child:Padding(padding:const EdgeInsets.all(22),child:Column(children:[
        const Icon(Icons.construction,size:65,color:Colors.red),
        const Text('HUSENI VASILA',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),
        const Text('Contractor • Hajri • Site Manager'),
        const SizedBox(height:18),
        SegmentedButton<bool>(segments:const[
          ButtonSegment(value:false,label:Text('Admin')),
          ButtonSegment(value:true,label:Text('Worker'))],
          selected:{worker},onSelectionChanged:(s)=>setState(()=>worker=s.first)),
        const SizedBox(height:12),
        TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'Mobile Number',border:OutlineInputBorder())),
        const SizedBox(height:10),
        TextField(controller:pin,obscureText:true,decoration:const InputDecoration(labelText:'PIN',border:OutlineInputBorder())),
        const SizedBox(height:15),
        SizedBox(width:double.infinity,child:FilledButton(
          onPressed:()=>Navigator.pushReplacement(c,MaterialPageRoute(builder:(_)=>worker?const Worker():const Admin())),
          child:Text(worker?'Worker Login':'Admin Login'))),
        const SizedBox(height:8),
        const Text('Demo login • Cloud sync can be connected next',style:TextStyle(color:Colors.grey))
      ]))
    )))
  );
}

class Admin extends StatefulWidget{const Admin({super.key});@override State<Admin> createState()=>_AdminState();}
class _AdminState extends State<Admin>{
  int tab=0;
  final pages=const[Dashboard(),Attendance(),Staff(),Sites(),MaterialEntry(),Payments(),Support()];
  @override Widget build(BuildContext c)=>Scaffold(
    appBar:AppBar(title:const Text('HUSENI VASILA'),backgroundColor:Colors.red,foregroundColor:Colors.white),
    body:pages[tab],
    bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),
      destinations:const[
        NavigationDestination(icon:Icon(Icons.home),label:'Home'),
        NavigationDestination(icon:Icon(Icons.calendar_month),label:'Hajri'),
        NavigationDestination(icon:Icon(Icons.people),label:'Staff'),
        NavigationDestination(icon:Icon(Icons.location_city),label:'Site'),
        NavigationDestination(icon:Icon(Icons.inventory),label:'Material'),
        NavigationDestination(icon:Icon(Icons.payments),label:'Payment'),
        NavigationDestination(icon:Icon(Icons.support_agent),label:'Support')])
  );
}

class Dashboard extends StatelessWidget{const Dashboard({super.key});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
 const Text('Dashboard',style:TextStyle(fontSize:30,fontWeight:FontWeight.bold)),
 const SizedBox(height:5),Text(DateFormat('dd MMMM yyyy').format(DateTime.now())),
 const SizedBox(height:18),
 const Wrap(spacing:12,runSpacing:12,children:[
  InfoCard('👷','Staff'),InfoCard('📅','Hajri Book'),InfoCard('🏗️','Sites'),InfoCard('📦','Material'),InfoCard('💰','Payment'),InfoCard('📄','Reports'),InfoCard('🎥','Video Upload'),InfoCard('🆘','Support')]),
 const SizedBox(height:18),
 Card(child:ListTile(leading:const Icon(Icons.sync,color:Colors.green),title:const Text('Worker → Admin Sync'),subtitle:const Text('Final production version will use cloud database for live entries.')))
]);}
class InfoCard extends StatelessWidget{final String icon,title;const InfoCard(this.icon,this.title,{super.key});@override Widget build(BuildContext c)=>SizedBox(width:160,height:100,child:Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(icon,style:const TextStyle(fontSize:28)),Text(title,style:const TextStyle(fontWeight:FontWeight.bold))]))));}

class Attendance extends StatefulWidget{const Attendance({super.key});@override State<Attendance> createState()=>_AttendanceState();}
class _AttendanceState extends State<Attendance>{
 final names=['Raju Mistri','Salim','Imran','Arif','Ramesh'];
 final Map<String,String> today={};
 @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(12),children:[
  const Text('Hajri Book',style:TextStyle(fontSize:27,fontWeight:FontWeight.bold)),
  Text(DateFormat('dd MMMM yyyy').format(DateTime.now())),
  const SizedBox(height:12),
  Card(child:SingleChildScrollView(scrollDirection:Axis.horizontal,child:DataTable(
   columns:const[DataColumn(label:Text('Worker')),DataColumn(label:Text('P')),DataColumn(label:Text('A')),DataColumn(label:Text('H'))],
   rows:names.map((n)=>DataRow(cells:[DataCell(Text(n)),...['P','A','H'].map((s)=>DataCell(IconButton(
     onPressed:()async{today[n]=s;final a=await DB.get('attendance');a.removeWhere((x)=>x['date']==DateTime.now().toIso8601String().substring(0,10)&&x['worker']==n);a.add({'date':DateTime.now().toIso8601String().substring(0,10),'worker':n,'status':s,'time':DateTime.now().toIso8601String()});await DB.put('attendance',a);setState((){});},
     icon:CircleAvatar(radius:15,backgroundColor:today[n]==s?Colors.red:Colors.grey.shade200,child:Text(s,style:TextStyle(color:today[n]==s?Colors.white:Colors.black)))))).toList()])).toList())))
 ]);
}

class Staff extends StatefulWidget{const Staff({super.key});@override State<Staff> createState()=>_StaffState();}
class _StaffState extends State<Staff>{
 final n=TextEditingController(),m=TextEditingController(),r=TextEditingController(),rate=TextEditingController();List<Map<String,dynamic>> list=[];
 @override void initState(){super.initState();load();}
 Future<void>load()async{list=await DB.get('staff');setState((){});}
 Future<void>add()async{if(n.text.trim().isEmpty)return;list.add({'name':n.text,'mobile':m.text,'role':r.text,'rate':rate.text});await DB.put('staff',list);n.clear();m.clear();r.clear();rate.clear();setState((){});}
 @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
  const Text('Staff Entry',style:TextStyle(fontSize:27,fontWeight:FontWeight.bold)),
  for(final x in [n,m,r,rate])Padding(padding:const EdgeInsets.only(top:9),child:TextField(controller:x,keyboardType:x==rate?TextInputType.number:TextInputType.text,decoration:InputDecoration(labelText:x==n?'Worker Name':x==m?'Mobile Number':x==r?'Role':'Daily Rate ₹',border:const OutlineInputBorder()))),
  const SizedBox(height:10),FilledButton.icon(onPressed:add,icon:const Icon(Icons.add),label:const Text('Add Staff')),
  ...list.map((x)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(x['name']),subtitle:Text('${x['role']} • ₹${x['rate']} • ${x['mobile']}'))))
 ]);}
class Sites extends StatelessWidget{const Sites({super.key});@override Widget build(BuildContext c)=>Entry(title:'Site Entry',fields:const['Site Name','Customer Name','Address','Work Status']);}
class MaterialEntry extends StatelessWidget{const MaterialEntry({super.key});@override Widget build(BuildContext c)=>Entry(title:'Material Entry',fields:const['Material Name','Quantity','Unit','Rate ₹','Site']);}
class Payments extends StatelessWidget{const Payments({super.key});@override Widget build(BuildContext c)=>Entry(title:'Payment Entry',fields:const['Worker','Amount ₹','Date','Note']);}
class Entry extends StatefulWidget{final String title;final List<String>fields;const Entry({required this.title,required this.fields,super.key});@override State<Entry>createState()=>_EntryState();}
class _EntryState extends State<Entry>{late List<TextEditingController>cs;@override void initState(){super.initState();cs=widget.fields.map((_)=>TextEditingController()).toList();}@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[Text(widget.title,style:const TextStyle(fontSize:27,fontWeight:FontWeight.bold)),...List.generate(widget.fields.length,(i)=>Padding(padding:const EdgeInsets.only(top:10),child:TextField(controller:cs[i],decoration:InputDecoration(labelText:widget.fields[i],border:const OutlineInputBorder())))),const SizedBox(height:12),FilledButton(onPressed:()=>ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('Entry saved.'))),child:const Text('Save Entry'))]);}
class Support extends StatelessWidget{const Support({super.key});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Support',style:TextStyle(fontSize:27,fontWeight:FontWeight.bold)),const SizedBox(height:15),const Card(child:ListTile(leading:Icon(Icons.help),title:Text('Help & Support'),subtitle:Text('Contact your app administrator for assistance.'))),const Card(child:ListTile(leading:Icon(Icons.video_library),title:Text('Video Upload'),subtitle:Text('Video upload storage will be connected in the next backend step.')))]);}
class Worker extends StatefulWidget{const Worker({super.key});@override State<Worker>createState()=>_WorkerState();}
class _WorkerState extends State<Worker>{String s='-';@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Worker App'),backgroundColor:Colors.red,foregroundColor:Colors.white),body:ListView(padding:const EdgeInsets.all(16),children:[const Text('My Hajri',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),Text(DateFormat('dd MMMM yyyy').format(DateTime.now())),const SizedBox(height:18),Row(children:['P','H','A'].map((x)=>Expanded(child:Padding(padding:const EdgeInsets.all(4),child:FilledButton(onPressed:()=>setState(()=>s=x),child:Text(x,style:const TextStyle(fontSize:20)))))).toList()),const SizedBox(height:14),Card(child:ListTile(leading:const Icon(Icons.check_circle,color:Colors.green),title:Text('Today: $s'),subtitle:const Text('Worker entry is saved locally; connect cloud backend for live Admin sync.'))),const SizedBox(height:10),const Card(child:ListTile(leading:Icon(Icons.location_city),title:Text('Site Entry'))),const Card(child:ListTile(leading:Icon(Icons.inventory),title:Text('Material Entry'))),const Card(child:ListTile(leading:Icon(Icons.payments),title:Text('Payment / Advance')))]));}
