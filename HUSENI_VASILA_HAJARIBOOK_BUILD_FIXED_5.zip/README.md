# HajariBook / Huseni Vasila

Functional Flutter demo build.

The dashboard cards, feature cards, attendance controls, worker actions, petty cash, profile settings, and navigation are clickable. Records added in the running session are stored in memory.

For production use, connect camera/face recognition, GPS/geofencing, QR scanning, persistent database, authentication, payroll calculations, and WhatsApp/email services to the corresponding screens.
