
import 'package:flutter/material.dart';

void main() => runApp(const HajariBookApp());

const primaryColor = Color(0xFF6653E8);
const backgroundColor = Color(0xFFF5F6FA);

class HajariBookApp extends StatelessWidget {
  const HajariBookApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'HajariBook',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: backgroundColor,
        colorScheme: ColorScheme.fromSeed(seedColor: primaryColor),
      ),
      home: const AppShell(),
    );
  }
}

class Worker {
  final String name;
  final String role;
  const Worker(this.name, this.role);
}

const workers = <Worker>[
  Worker('Afzal Hundada', 'Mason'),
  Worker('Arif chabba', 'Mason'),
  Worker('Ayaan Subhaniya', 'Mason'),
  Worker('Bhayani Ajijj', 'Mason'),
  Worker('Dadu Chabba', 'Helper'),
  Worker('Gafur Chamadiya', 'Helper'),
  Worker('Hajar baai', 'Labour'),
  Worker('Husein Godivara', 'Helper'),
  Worker('Ibrahim M Shodha', 'Mason'),
  Worker('Nadim Alvani', 'Mason'),
  Worker('Nashim', 'Labour'),
  Worker('Navaz Manek', 'Helper'),
  Worker('Nawaz bhukeda', 'Helper'),
  Worker('Nawaz Sameja', 'Helper'),
  Worker('Sahil', 'Mason'),
  Worker('Salman', 'Helper'),
  Worker('Shahid', 'Labour'),
  Worker('Yusuf', 'Mason'),
];

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;

  final pages = const [
    DashboardPage(),
    AttendancePage(),
    WorkforcePage(),
    PettyCashPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.person_pin_outlined), selectedIcon: Icon(Icons.person_pin), label: 'Attendance'),
          NavigationDestination(icon: Icon(Icons.groups_outlined), selectedIcon: Icon(Icons.groups), label: 'Workforce'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'PettyCash'),
          NavigationDestination(icon: Icon(Icons.account_circle_outlined), selectedIcon: Icon(Icons.account_circle), label: 'Profile'),
        ],
      ),
    );
  }
}

Widget pageHeader(String title, {Widget? right, double height = 136}) {
  return Container(
    height: height,
    width: double.infinity,
    padding: const EdgeInsets.fromLTRB(22, 48, 22, 14),
    decoration: const BoxDecoration(
      color: primaryColor,
      borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
    ),
    child: Row(
      children: [
        Expanded(child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800))),
        right ?? const Icon(Icons.headset_mic_outlined, color: Colors.white),
      ],
    ),
  );
}

void openFeature(BuildContext context, String title, IconData icon) {
  Navigator.push(context, MaterialPageRoute(builder: (_) => FeaturePage(title: title, icon: icon)));
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    final features = [
      ('Worker Dashboard', Icons.person_add_alt_1, const Color(0xFFF1C9B7)),
      ('Material', Icons.local_shipping_outlined, const Color(0xFFCDE7F5)),
      ('My Usage', Icons.donut_large, const Color(0xFFC9C1F0)),
      ('DPR', Icons.receipt_long, const Color(0xFFB8E9E3)),
      ('Accounting', Icons.receipt, const Color(0xFFBCE7D3)),
      ('Reports', Icons.bar_chart, const Color(0xFFF3B9E8)),
      ('Leave Approvals', Icons.fact_check_outlined, const Color(0xFFC9C1F0)),
      ('Petty Cash Balance', Icons.account_balance_wallet, const Color(0xFFF5E9A7)),
      ('Loan Ledger', Icons.menu_book, const Color(0xFFD8D0F7)),
      ('Incentive', Icons.card_giftcard, const Color(0xFFF6D2A7)),
      ('Live Location', Icons.location_on, const Color(0xFFC5D2F7)),
      ('QR Attendance', Icons.qr_code_scanner, const Color(0xFFBDE8D8)),
    ];

    return SafeArea(
      top: false,
      child: Column(
        children: [
          pageHeader('Dashboard'),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(22),
              children: [
                Row(
                  children: [
                    const Icon(Icons.explore),
                    const SizedBox(width: 8),
                    const Expanded(child: Text('Explore Features', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
                    TextButton(
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AllFeaturesPage())),
                      child: const Text('View All ›'),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: _topCard(
                        context, 'Lens App', 'Face recognition\nattendance',
                        Icons.face_retouching_natural, const Color(0xFFB8EBCF), 'Selfie / Face Attendance',
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: _topCard(
                        context, 'View Live Location', 'Track workers in real-time',
                        Icons.location_pin, const Color(0xFFC5D2F7), 'Live Location',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => _showMessage(context, 'Starter Plan', 'Premium features are available in this demo build.'),
                  child: Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: primaryColor)),
                    child: const Row(
                      children: [
                        CircleAvatar(backgroundColor: Color(0xFFE9E6FF), child: Icon(Icons.workspace_premium, color: primaryColor)),
                        SizedBox(width: 14),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('Current Plan: Starter', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                          Text('You have access to premium features', style: TextStyle(fontWeight: FontWeight.w600, color: Colors.black54)),
                        ])),
                        Icon(Icons.chevron_right),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: features.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .92,
                  ),
                  itemBuilder: (context, i) {
                    final item = features[i];
                    return InkWell(
                      borderRadius: BorderRadius.circular(22),
                      onTap: () => openFeature(context, item.$1, item.$2),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(color: item.$3, borderRadius: BorderRadius.circular(22)),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Icon(item.$2, size: 31),
                          const Spacer(),
                          Text(item.$1, style: const TextStyle(fontWeight: FontWeight.w800)),
                        ]),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 20),
                InkWell(
                  borderRadius: BorderRadius.circular(20),
                  onTap: () => openFeature(context, 'Real Estate CRM', Icons.business_center),
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(color: const Color(0xFFDDEEFF), borderRadius: BorderRadius.circular(20)),
                    child: const Row(children: [
                      Icon(Icons.business_center, color: primaryColor, size: 30),
                      SizedBox(width: 15),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Real Estate CRM', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                        Text('Property sales & lead management', style: TextStyle(color: Colors.black54, fontWeight: FontWeight.w600)),
                      ])),
                      Icon(Icons.chevron_right),
                    ]),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _topCard(BuildContext context, String title, String subtitle, IconData icon, Color color, String feature) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: () => openFeature(context, feature, icon),
      child: Container(
        height: 116,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(22)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: primaryColor),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          Text(subtitle, style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.black54)),
        ]),
      ),
    );
  }
}

class AllFeaturesPage extends StatelessWidget {
  const AllFeaturesPage({super.key});
  @override
  Widget build(BuildContext context) {
    final items = [
      ('Selfie / Face Attendance', Icons.face),
      ('Geo-Fencing', Icons.location_searching),
      ('QR Attendance', Icons.qr_code_2),
      ('Scheduled Auto-Attendance', Icons.schedule),
      ('Monthly Payroll', Icons.payments),
      ('Weekly Payroll', Icons.calendar_view_week),
      ('Salary Slips', Icons.receipt_long),
      ('Overtime', Icons.more_time),
      ('Material & Inventory', Icons.local_shipping),
      ('Petty Cash', Icons.account_balance_wallet),
      ('Leave Management', Icons.event_available),
      ('Loan Ledger', Icons.menu_book),
      ('Incentive', Icons.card_giftcard),
      ('Live Location', Icons.location_on),
      ('Invoicing', Icons.request_quote),
      ('Reports', Icons.bar_chart),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('All Features')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, i) => Card(
          child: ListTile(
            leading: CircleAvatar(backgroundColor: const Color(0xFFEDE8FF), child: Icon(items[i].$2, color: primaryColor)),
            title: Text(items[i].$1, style: const TextStyle(fontWeight: FontWeight.w700)),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => openFeature(context, items[i].$1, items[i].$2),
          ),
        ),
      ),
    );
  }
}

class FeaturePage extends StatefulWidget {
  final String title;
  final IconData icon;
  const FeaturePage({super.key, required this.title, required this.icon});
  @override
  State<FeaturePage> createState() => _FeaturePageState();
}

class _FeaturePageState extends State<FeaturePage> {
  final items = <String>[];
  final controller = TextEditingController();

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void addItem() {
    final text = controller.text.trim();
    if (text.isEmpty) return;
    setState(() => items.add(text));
    controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    final isAttendance = widget.title.contains('Attendance') || widget.title.contains('Face') || widget.title.contains('QR') || widget.title.contains('Geo');
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          CircleAvatar(radius: 34, backgroundColor: const Color(0xFFEDE8FF), child: Icon(widget.icon, size: 34, color: primaryColor)),
          const SizedBox(height: 14),
          Text(widget.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(
            isAttendance
                ? 'Attendance module is ready. Use the actions below to test the workflow.'
                : 'This module is clickable and ready for adding and viewing records in this demo build.',
            style: const TextStyle(color: Colors.black54, fontSize: 16),
          ),
          const SizedBox(height: 20),
          if (isAttendance) ...[
            FilledButton.icon(onPressed: () => _showMessage(context, 'Attendance', 'Camera/location workflow can be connected here.'), icon: const Icon(Icons.camera_alt), label: const Text('Mark Self Attendance')),
            const SizedBox(height: 10),
            OutlinedButton.icon(onPressed: () => _showMessage(context, 'QR Attendance', 'QR scanner screen opened successfully.'), icon: const Icon(Icons.qr_code_scanner), label: const Text('Scan QR Code')),
          ] else ...[
            TextField(
              controller: controller,
              decoration: InputDecoration(labelText: 'Add record', suffixIcon: IconButton(onPressed: addItem, icon: const Icon(Icons.add))),
              onSubmitted: (_) => addItem(),
            ),
            const SizedBox(height: 12),
            if (items.isEmpty)
              const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('No records yet. Add one above.')))
            else
              ...items.map((e) => Card(child: ListTile(title: Text(e), trailing: const Icon(Icons.check_circle, color: Colors.green)))),
          ],
        ],
      ),
      floatingActionButton: !isAttendance ? FloatingActionButton(onPressed: addItem, child: const Icon(Icons.add)) : null,
    );
  }
}

class AttendancePage extends StatefulWidget {
  const AttendancePage({super.key});
  @override
  State<AttendancePage> createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage> {
  final Map<String, String> status = {};
  DateTime selectedDate = DateTime.now();

  String _formatDate(DateTime value) {
    const weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return '${weekdays[value.weekday - 1]} ${value.day} ${months[value.month - 1]}';
  }

  @override
  Widget build(BuildContext context) {
    final mason = workers.where((w) => w.role == 'Mason').toList();
    final helper = workers.where((w) => w.role == 'Helper').toList();
    final labour = workers.where((w) => w.role == 'Labour').toList();
    return SafeArea(
      top: false,
      child: Column(children: [
        Container(
          height: 136, color: primaryColor, padding: const EdgeInsets.fromLTRB(16, 48, 16, 10),
          child: Column(children: [
            Row(children: [
              const Expanded(child: Text('Current Site\nDefault Site  ▾', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800))),
              IconButton(onPressed: () => openFeature(context, 'QR Attendance', Icons.qr_code_scanner), icon: const Icon(Icons.qr_code_scanner, color: Colors.white)),
              IconButton(onPressed: () => _showMessage(context, 'Search', 'Search attendance is ready.'), icon: const Icon(Icons.search, color: Colors.white)),
              IconButton(onPressed: () => _showMessage(context, 'Attendance Settings', 'Attendance settings opened.'), icon: const Icon(Icons.more_vert, color: Colors.white)),
            ]),
            const SizedBox(height: 6),
            Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
              IconButton(onPressed: () => setState(() => selectedDate = selectedDate.subtract(const Duration(days: 1))), icon: const Icon(Icons.chevron_left, color: Colors.white)),
              Text(_formatDate(selectedDate), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
              IconButton(onPressed: () => setState(() => selectedDate = selectedDate.add(const Duration(days: 1))), icon: const Icon(Icons.chevron_right, color: Colors.white)),
            ]),
          ]),
        ),
        Expanded(child: ListView(children: [
          _workerGroup('Mason', mason),
          _workerGroup('Helper', helper),
          _workerGroup('Labour', labour),
        ])),
      ]),
    );
  }

  Widget _workerGroup(String title, List<Worker> list) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(width: double.infinity, padding: const EdgeInsets.all(10), color: const Color(0xFFF0F1F5),
        child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17))),
      ...list.map((worker) => _workerRow(worker)),
    ],
  );

  Widget _workerRow(Worker worker) {
    final current = status[worker.name] ?? 'P';
    return InkWell(
      onTap: () => _showWorkerMenu(worker),
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 14, 12, 13),
        decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xFFE0E0E0)))),
        child: Column(children: [
          Row(children: [
            Expanded(child: Text(worker.name, style: const TextStyle(color: primaryColor, fontWeight: FontWeight.w800, fontSize: 17))),
            OutlinedButton(onPressed: () => _payWorker(worker), child: const Text('Pay')),
            IconButton(onPressed: () => _showWorkerMenu(worker), icon: const Icon(Icons.more_vert)),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            _button('IN', current == 'IN', () => _set(worker, 'IN')),
            _button('OUT', current == 'OUT', () => _set(worker, 'OUT')),
            const Spacer(),
            for (final s in ['P', 'P+P', 'P+½', 'A', 'H', 'OT'])
              _button(s, current == s, () => _set(worker, s)),
          ]),
        ]),
      ),
    );
  }

  Widget _button(String text, bool selected, VoidCallback onTap) => Padding(
    padding: const EdgeInsets.only(right: 5),
    child: InkWell(
      borderRadius: BorderRadius.circular(11),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? primaryColor : Colors.white,
          border: Border.all(color: selected ? primaryColor : const Color(0xFFE0E0E0)),
          borderRadius: BorderRadius.circular(11),
        ),
        child: Text(text, style: TextStyle(color: selected ? Colors.white : primaryColor, fontWeight: FontWeight.w800)),
      ),
    ),
  );

  void _set(Worker w, String value) => setState(() => status[w.name] = value);

  void _payWorker(Worker worker) {
    final c = TextEditingController();
    showDialog(context: context, builder: (d) => AlertDialog(
      title: Text('Pay ${worker.name}'),
      content: TextField(controller: c, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Amount')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
        FilledButton(onPressed: () { Navigator.pop(d); _showMessage(context, 'Payment saved', '₹${c.text.trim()} recorded for ${worker.name}.'); }, child: const Text('Save')),
      ],
    ));
  }

  void _showWorkerMenu(Worker worker) {
    showModalBottomSheet(context: context, builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
      ListTile(leading: const Icon(Icons.person), title: Text(worker.name), subtitle: Text(worker.role)),
      ListTile(leading: const Icon(Icons.payments), title: const Text('Pay worker'), onTap: () { Navigator.pop(context); _payWorker(worker); }),
      ListTile(leading: const Icon(Icons.history), title: const Text('View attendance'), onTap: () { Navigator.pop(context); _showMessage(context, 'Attendance', '${worker.name}: ${status[worker.name] ?? 'P'}'); }),
    ])));
  }
}

class WorkforcePage extends StatefulWidget {
  const WorkforcePage({super.key});
  @override
  State<WorkforcePage> createState() => _WorkforcePageState();
}

class _WorkforcePageState extends State<WorkforcePage> {
  late List<Worker> list = workers.toList();
  String query = '';

  @override
  Widget build(BuildContext context) {
    final filtered = list.where((w) => w.name.toLowerCase().contains(query.toLowerCase())).toList();
    return SafeArea(
      top: false,
      child: Column(children: [
        pageHeader('Manage Workforce', right: Row(mainAxisSize: MainAxisSize.min, children: [
          IconButton(onPressed: _search, icon: const Icon(Icons.search, color: Colors.white)),
          IconButton(onPressed: _addWorker, icon: const Icon(Icons.person_add, color: Colors.white)),
        ])),
        Padding(padding: const EdgeInsets.all(16), child: Row(children: [
          Text('Active: ${list.length}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const Spacer(),
          IconButton(onPressed: _addWorker, icon: const Icon(Icons.add_circle, color: primaryColor)),
        ])),
        Expanded(child: ListView.builder(
          itemCount: filtered.length,
          itemBuilder: (_, i) {
            final worker = filtered[i];
            return ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 22, vertical: 5),
              leading: const CircleAvatar(radius: 27, backgroundColor: Color(0xFFD7C8F8), child: Icon(Icons.person, color: Colors.white)),
              title: Text(worker.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
              subtitle: Text('${worker.role} / Default Site', style: const TextStyle(fontWeight: FontWeight.w600)),
              trailing: IconButton(onPressed: () => _workerActions(worker), icon: const Icon(Icons.more_vert)),
              onTap: () => _workerActions(worker),
            );
          },
        )),
      ]),
    );
  }

  void _search() {
    final c = TextEditingController(text: query);
    showDialog(context: context, builder: (d) => AlertDialog(
      title: const Text('Search Worker'),
      content: TextField(controller: c, autofocus: true, decoration: const InputDecoration(hintText: 'Worker name')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
        FilledButton(onPressed: () { setState(() => query = c.text); Navigator.pop(d); }, child: const Text('Search')),
      ],
    ));
  }

  void _addWorker() {
    final name = TextEditingController();
    final role = TextEditingController(text: 'Mason');
    showDialog(context: context, builder: (d) => AlertDialog(
      title: const Text('Add Worker'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')),
        TextField(controller: role, decoration: const InputDecoration(labelText: 'Role')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
        FilledButton(onPressed: () {
          if (name.text.trim().isNotEmpty) setState(() => list.add(Worker(name.text.trim(), role.text.trim().isEmpty ? 'Worker' : role.text.trim())));
          Navigator.pop(d);
        }, child: const Text('Add')),
      ],
    ));
  }

  void _workerActions(Worker worker) {
    showModalBottomSheet(context: context, builder: (_) => SafeArea(child: Wrap(children: [
      ListTile(title: Text(worker.name), subtitle: Text(worker.role)),
      ListTile(leading: const Icon(Icons.payments), title: const Text('Open Pagar'), onTap: () { Navigator.pop(context); openFeature(context, 'Worker Pagar', Icons.payments); }),
      ListTile(leading: const Icon(Icons.delete_outline), title: const Text('Remove worker'), onTap: () { Navigator.pop(context); setState(() => list.remove(worker)); }),
    ])));
  }
}

class PettyCashPage extends StatefulWidget {
  const PettyCashPage({super.key});
  @override
  State<PettyCashPage> createState() => _PettyCashPageState();
}

class _PettyCashPageState extends State<PettyCashPage> {
  final entries = <String>[];
  double balance = 0;

  void addPettyCash() {
    final desc = TextEditingController();
    final amount = TextEditingController();
    showDialog(context: context, builder: (d) => AlertDialog(
      title: const Text('Add Petty Cash'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: desc, decoration: const InputDecoration(labelText: 'Description')),
        TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Amount')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
        FilledButton(onPressed: () {
          final value = double.tryParse(amount.text.trim()) ?? 0;
          if (desc.text.trim().isNotEmpty && value > 0) setState(() { balance += value; entries.add('${desc.text.trim()} — ₹${value.toStringAsFixed(2)}'); });
          Navigator.pop(d);
        }, child: const Text('Add')),
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(top: false, child: Column(children: [
      Container(height: 136, color: primaryColor, padding: const EdgeInsets.fromLTRB(22, 48, 22, 15), child: Row(children: [
        const Expanded(child: Text('Pettycash account\nDefault Account  ▾', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800))),
        Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
          child: Text('₹${balance.toStringAsFixed(2)}', style: const TextStyle(color: Colors.green, fontWeight: FontWeight.w800))),
        const SizedBox(width: 12),
        IconButton(onPressed: () => _showMessage(context, 'Settings', 'Petty cash settings opened.'), icon: const Icon(Icons.settings, color: Colors.white)),
      ])),
      Padding(padding: const EdgeInsets.all(18), child: Row(children: [
        const Text('No Filters Applied', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
        const Spacer(),
        IconButton(onPressed: () => _showMessage(context, 'Filter', 'Filter options opened.'), icon: const Icon(Icons.filter_list)),
        IconButton(onPressed: () => _showMessage(context, 'Sort', 'Sort options opened.'), icon: const Icon(Icons.sort)),
      ])),
      Expanded(
        child: entries.isEmpty
            ? const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('No items found', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                    Text('Tap + to add a cash entry.', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                  ],
                ),
              )
            : ListView.builder(
                itemCount: entries.length,
                itemBuilder: (context, index) => ListTile(
                  leading: const Icon(Icons.payments),
                  title: Text(entries[index], style: const TextStyle(fontWeight: FontWeight.w700)),
                ),
              ),
      ),
      Align(alignment: Alignment.bottomRight, child: Padding(padding: const EdgeInsets.all(20), child: FloatingActionButton(backgroundColor: primaryColor, onPressed: addPettyCash, child: const Icon(Icons.add, color: Colors.white)))),
    ]));
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(top: false, child: Column(children: [
      Container(height: 285, width: double.infinity, padding: const EdgeInsets.fromLTRB(22, 58, 22, 20),
        decoration: const BoxDecoration(color: primaryColor, borderRadius: BorderRadius.vertical(bottom: Radius.circular(30))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
          Text('Profile', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w800)),
          SizedBox(height: 24),
          Row(children: [
            CircleAvatar(radius: 48, backgroundColor: Color(0xFFD8C8F4), child: Icon(Icons.person, size: 55, color: Colors.white)),
            SizedBox(width: 16),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Huseni Vasila', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
              Text('Company Owner', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
              Text('HajariBook', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
              Text('v1.0.1', style: TextStyle(color: Colors.white70)),
            ])),
          ]),
        ]),
      ),
      Expanded(child: ListView(padding: const EdgeInsets.all(22), children: [
        _section(context, 'ACCOUNT SETTINGS', [
          ('Edit Profile', 'Company & GST details', Icons.edit),
          ('Master App Data Setup', 'Sites, category, material, petty cash', Icons.tune),
          ('Settings & More', 'Language, menu, plan, invoices', Icons.settings),
        ]),
        _section(context, 'EXPERIENCE & GROWTH', [
          ('How Features Work', 'Videos and guides', Icons.play_circle_outline),
          ('Upcoming Features', 'Features and updates', Icons.upcoming),
          ('Refer a Friend', 'Share HajariBook', Icons.share),
        ]),
        _section(context, 'SUPPORT & COMMUNITY', [
          ('Join Our Community', 'WhatsApp channel', Icons.groups),
          ('Rate 5 Stars', 'Tell us how we are doing', Icons.star),
        ]),
      ])),
    ]));
  }

  Widget _section(BuildContext context, String heading, List<(String, String, IconData)> items) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(padding: const EdgeInsets.only(left: 6, bottom: 10), child: Text(heading, style: const TextStyle(letterSpacing: 1.5, color: Colors.black54, fontWeight: FontWeight.w800))),
      Container(decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)), child: Column(
        children: items.map((item) => ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
          leading: CircleAvatar(backgroundColor: const Color(0xFFEDE8FF), child: Icon(item.$3, color: primaryColor)),
          title: Text(item.$1, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          subtitle: Text(item.$2, style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.black54)),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _profileAction(context, item.$1),
        )).toList(),
      )),
      const SizedBox(height: 25),
    ]);
  }

  void _profileAction(BuildContext context, String title) {
    if (title == 'Refer a Friend') {
      _showMessage(context, title, 'Share link action is ready to connect.');
    } else if (title == 'Join Our Community') {
      _showMessage(context, title, 'Community action is ready to connect.');
    } else {
      openFeature(context, title, Icons.settings);
    }
  }
}

void _showMessage(BuildContext context, String title, String message) {
  showDialog<void>(context: context, builder: (d) => AlertDialog(
    title: Text(title),
    content: Text(message),
    actions: [FilledButton(onPressed: () => Navigator.pop(d), child: const Text('OK'))],
  ));
}
