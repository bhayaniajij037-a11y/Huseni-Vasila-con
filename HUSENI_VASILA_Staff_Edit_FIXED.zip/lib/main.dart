import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:intl/intl.dart';

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
    debugShowCheckedModeBanner:false,
    title:'Huseni Vasila',
    theme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.red),
    home:const Login(),
  );
}

class DB {
  static Future<List<Map<String,dynamic>>> get(String key) async {
    final p=await SharedPreferences.getInstance();
    final s=p.getString(key);
    if(s==null)return [];
    return List<Map<String,dynamic>>.from((jsonDecode(s) as List).map((e)=>Map<String,dynamic>.from(e)));
  }
  static Future<void> put(String key,List<Map<String,dynamic>> v) async {
    final p=await SharedPreferences.getInstance();
    await p.setString(key,jsonEncode(v));
  }
}

class Login extends StatefulWidget { const Login({super.key}); @override State<Login> createState()=>_LoginState(); }
class _LoginState extends State<Login>{
  bool worker=false;
  final phone=TextEditingController(),pin=TextEditingController();
  @override Widget build(BuildContext c)=>Scaffold(
    body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(22),child:Card(
      child:Padding(padding:const EdgeInsets.all(22),child:Column(children:[
        const Icon(Icons.construction,size:65,color:Colors.red),
        const Text('HUSENI VASILA',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),
        const Text('Contractor • Hajri • Site Manager'),
        const SizedBox(height:18),
        SegmentedButton<bool>(segments:const[
          ButtonSegment(value:false,label:Text('Admin')),
          ButtonSegment(value:true,label:Text('Worker'))],
          selected:{worker},onSelectionChanged:(s)=>setState(()=>worker=s.first)),
        const SizedBox(height:12),
        TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'Mobile Number',border:OutlineInputBorder())),
        const SizedBox(height:10),
        TextField(controller:pin,obscureText:true,decoration:const InputDecoration(labelText:'PIN',border:OutlineInputBorder())),
        const SizedBox(height:15),
        SizedBox(width:double.infinity,child:FilledButton(
          onPressed:()=>Navigator.pushReplacement(c,MaterialPageRoute(builder:(_)=>worker?const Worker():const Admin())),
          child:Text(worker?'Worker Login':'Admin Login'))),
        const SizedBox(height:8),
        const Text('Demo login • Cloud sync can be connected next',style:TextStyle(color:Colors.grey))
      ]))
    )))
  );
}

class Admin extends StatefulWidget{const Admin({super.key});@override State<Admin> createState()=>_AdminState();}
class _AdminState extends State<Admin>{
  int tab=0;
  final pages=const[Dashboard(),Attendance(),Staff(),Sites(),MaterialEntry(),Payments(),Support()];
  @override Widget build(BuildContext c)=>Scaffold(
    appBar:AppBar(title:const Text('HUSENI VASILA'),backgroundColor:Colors.red,foregroundColor:Colors.white),
    body:pages[tab],
    bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),
      destinations:const[
        NavigationDestination(icon:Icon(Icons.home),label:'Home'),
        NavigationDestination(icon:Icon(Icons.calendar_month),label:'Hajri'),
        NavigationDestination(icon:Icon(Icons.people),label:'Staff'),
        NavigationDestination(icon:Icon(Icons.location_city),label:'Site'),
        NavigationDestination(icon:Icon(Icons.inventory),label:'Material'),
        NavigationDestination(icon:Icon(Icons.payments),label:'Payment'),
        NavigationDestination(icon:Icon(Icons.support_agent),label:'Support')])
  );
}

class Dashboard extends StatelessWidget{const Dashboard({super.key});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
 const Text('Dashboard',style:TextStyle(fontSize:30,fontWeight:FontWeight.bold)),
 const SizedBox(height:5),Text(DateFormat('dd MMMM yyyy').format(DateTime.now())),
 const SizedBox(height:18),
 const Wrap(spacing:12,runSpacing:12,children:[
  InfoCard('👷','Staff'),InfoCard('📅','Hajri Book'),InfoCard('🏗️','Sites'),InfoCard('📦','Material'),InfoCard('💰','Payment'),InfoCard('📄','Reports'),InfoCard('🎥','Video Upload'),InfoCard('🆘','Support')]),
 const SizedBox(height:18),
 Card(child:ListTile(leading:const Icon(Icons.sync,color:Colors.green),title:const Text('Worker → Admin Sync'),subtitle:const Text('Final production version will use cloud database for live entries.')))
]);}
class InfoCard extends StatelessWidget{final String icon,title;const InfoCard(this.icon,this.title,{super.key});@override Widget build(BuildContext c)=>SizedBox(width:160,height:100,child:Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(icon,style:const TextStyle(fontSize:28)),Text(title,style:const TextStyle(fontWeight:FontWeight.bold))]))));}

class Attendance extends StatefulWidget{const Attendance({super.key});@override State<Attendance> createState()=>_AttendanceState();}
class _AttendanceState extends State<Attendance>{
  List<Map<String,dynamic>> staff=[];
  Map<String,String> today={};
  String get dateKey=>DateTime.now().toIso8601String().substring(0,10);
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    staff=await DB.get('staff');
    final a=await DB.get('attendance');
    today={for(final x in a.where((x)=>x['date']==dateKey)) x['worker'].toString():x['status'].toString()};
    if(mounted)setState((){});
  }
  Future<void> mark(String worker,String status)async{
    final a=await DB.get('attendance');
    a.removeWhere((x)=>x['date']==dateKey&&x['worker']==worker);
    a.add({'date':dateKey,'worker':worker,'status':status,'time':DateTime.now().toIso8601String()});
    await DB.put('attendance',a);
    today[worker]=status;
    if(mounted)setState((){});
  }
  @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(12),children:[
    const Text('Hajri Book',style:TextStyle(fontSize:27,fontWeight:FontWeight.bold)),
    Text(DateFormat('dd MMMM yyyy').format(DateTime.now())),
    const SizedBox(height:12),
    if(staff.isEmpty) const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('Pehle Staff page se worker add karein.'))),
    if(staff.isNotEmpty) Card(child:SingleChildScrollView(scrollDirection:Axis.horizontal,child:DataTable(
      columns:const[DataColumn(label:Text('Worker')),DataColumn(label:Text('P')),DataColumn(label:Text('A')),DataColumn(label:Text('H'))],
      rows:staff.map((x){final n=x['name'].toString();return DataRow(cells:[DataCell(Text(n)),...['P','A','H'].map((status)=>DataCell(IconButton(
        onPressed:()=>mark(n,status),
        icon:CircleAvatar(radius:15,backgroundColor:today[n]==status?Colors.red:Colors.grey.shade200,child:Text(status,style:TextStyle(color:today[n]==status?Colors.white:Colors.black))))))]);}).toList()
    )))
  ]);
}

class Staff extends StatefulWidget{const Staff({super.key});@override State<Staff> createState()=>_StaffState();}
class _StaffState extends State<Staff>{
  final n=TextEditingController(),m=TextEditingController(),r=TextEditingController(),rate=TextEditingController();
  List<Map<String,dynamic>> list=[];
  @override void initState(){super.initState();load();}
  @override void dispose(){n.dispose();m.dispose();r.dispose();rate.dispose();super.dispose();}
  Future<void>load()async{list=await DB.get('staff');if(mounted)setState((){});}
  Future<void>save()async{
    final name=n.text.trim();
    if(name.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Worker Name bharna zaroori hai.')));return;}
    list.add({'name':name,'mobile':m.text.trim(),'role':r.text.trim(),'rate':rate.text.trim()});
    await DB.put('staff',list);clear();if(mounted)setState((){});
  }
  void clear(){n.clear();m.clear();r.clear();rate.clear();}
  void fill(Map<String,dynamic>x){n.text=x['name']?.toString()??'';m.text=x['mobile']?.toString()??'';r.text=x['role']?.toString()??'';rate.text=x['rate']?.toString()??'';}
  Future<void>edit(int index)async{
    final name=n.text.trim();
    if(name.isEmpty)return;
    final old=list[index]['name'].toString();
    list[index]={'name':name,'mobile':m.text.trim(),'role':r.text.trim(),'rate':rate.text.trim()};
    await DB.put('staff',list);
    final a=await DB.get('attendance');
    for(final x in a){if(x['worker']==old)x['worker']=name;}
    await DB.put('attendance',a);
    clear();if(mounted)setState((){});
  }
  Future<void>remove(int index)async{
    final name=list[index]['name'].toString();
    final ok=await showDialog<bool>(context:context,builder:(d)=>AlertDialog(title:const Text('Delete Staff?'),content:Text('Remove $name?'),actions:[TextButton(onPressed:()=>Navigator.pop(d,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(d,true),child:const Text('Delete'))]))??false;
    if(!ok)return;
    list.removeAt(index);await DB.put('staff',list);if(mounted)setState((){});
  }
  Future<void>showEdit(int index)async{
    fill(list[index]);
    await showDialog(context:context,builder:(d)=>AlertDialog(title:const Text('Edit Staff'),content:SizedBox(width:400,child:SingleChildScrollView(child:Column(children:[
      TextField(controller:n,decoration:const InputDecoration(labelText:'Worker Name',border:OutlineInputBorder())),
      const SizedBox(height:8),TextField(controller:m,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'Mobile Number',border:OutlineInputBorder())),
      const SizedBox(height:8),TextField(controller:r,decoration:const InputDecoration(labelText:'Role',border:OutlineInputBorder())),
      const SizedBox(height:8),TextField(controller:rate,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Daily Rate ₹',border:OutlineInputBorder())),
    ]))),actions:[TextButton(onPressed:(){clear();Navigator.pop(d);},child:const Text('Cancel')),FilledButton(onPressed:()async{await edit(index);if(d.mounted)Navigator.pop(d);},child:const Text('Save Changes'))]));
  }
  @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Staff Entry',style:TextStyle(fontSize:27,fontWeight:FontWeight.bold)),
    TextField(controller:n,decoration:const InputDecoration(labelText:'Worker Name',border:OutlineInputBorder())),
    const SizedBox(height:9),TextField(controller:m,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'Mobile Number',border:OutlineInputBorder())),
    const SizedBox(height:9),TextField(controller:r,decoration:const InputDecoration(labelText:'Role',border:OutlineInputBorder())),
    const SizedBox(height:9),TextField(controller:rate,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Daily Rate ₹',border:OutlineInputBorder())),
    const SizedBox(height:10),FilledButton.icon(onPressed:save,icon:const Icon(Icons.add),label:const Text('Add Staff')),
    const SizedBox(height:8),
    ...List.generate(list.length,(i){final x=list[i];return Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(x['name']?.toString()??''),subtitle:Text('${x['role']??''} • ₹${x['rate']??''} • ${x['mobile']??''}'),trailing:Wrap(spacing:0,children:[IconButton(tooltip:'Edit',icon:const Icon(Icons.edit),onPressed:()=>showEdit(i)),IconButton(tooltip:'Delete',icon:const Icon(Icons.delete),onPressed:()=>remove(i))]));})
  ]);
}
class Sites extends StatelessWidget{const Sites({super.key});@override Widget build(BuildContext c)=>Entry(title:'Site Entry',fields:const['Site Name','Customer Name','Address','Work Status']);}
class MaterialEntry extends StatelessWidget{const MaterialEntry({super.key});@override Widget build(BuildContext c)=>Entry(title:'Material Entry',fields:const['Material Name','Quantity','Unit','Rate ₹','Site']);}
class Payments extends StatelessWidget{const Payments({super.key});@override Widget build(BuildContext c)=>Entry(title:'Payment Entry',fields:const['Worker','Amount ₹','Date','Note']);}
class Entry extends StatefulWidget{final String title;final List<String>fields;const Entry({required this.title,required this.fields,super.key});@override State<Entry>createState()=>_EntryState();}
class _EntryState extends State<Entry>{late List<TextEditingController>cs;@override void initState(){super.initState();cs=widget.fields.map((_)=>TextEditingController()).toList();}@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[Text(widget.title,style:const TextStyle(fontSize:27,fontWeight:FontWeight.bold)),...List.generate(widget.fields.length,(i)=>Padding(padding:const EdgeInsets.only(top:10),child:TextField(controller:cs[i],decoration:InputDecoration(labelText:widget.fields[i],border:const OutlineInputBorder())))),const SizedBox(height:12),FilledButton(onPressed:()=>ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('Entry saved.'))),child:const Text('Save Entry'))]);}
class Support extends StatelessWidget{const Support({super.key});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Support',style:TextStyle(fontSize:27,fontWeight:FontWeight.bold)),const SizedBox(height:15),const Card(child:ListTile(leading:Icon(Icons.help),title:Text('Help & Support'),subtitle:Text('Contact your app administrator for assistance.'))),const Card(child:ListTile(leading:Icon(Icons.video_library),title:Text('Video Upload'),subtitle:Text('Video upload storage will be connected in the next backend step.')))]);}
class Worker extends StatefulWidget{const Worker({super.key});@override State<Worker>createState()=>_WorkerState();}
class _WorkerState extends State<Worker>{String s='-';@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Worker App'),backgroundColor:Colors.red,foregroundColor:Colors.white),body:ListView(padding:const EdgeInsets.all(16),children:[const Text('My Hajri',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),Text(DateFormat('dd MMMM yyyy').format(DateTime.now())),const SizedBox(height:18),Row(children:['P','H','A'].map((x)=>Expanded(child:Padding(padding:const EdgeInsets.all(4),child:FilledButton(onPressed:()=>setState(()=>s=x),child:Text(x,style:const TextStyle(fontSize:20)))))).toList()),const SizedBox(height:14),Card(child:ListTile(leading:const Icon(Icons.check_circle,color:Colors.green),title:Text('Today: $s'),subtitle:const Text('Worker entry is saved locally; connect cloud backend for live Admin sync.'))),const SizedBox(height:10),const Card(child:ListTile(leading:Icon(Icons.location_city),title:Text('Site Entry'))),const Card(child:ListTile(leading:Icon(Icons.inventory),title:Text('Material Entry'))),const Card(child:ListTile(leading:Icon(Icons.payments),title:Text('Payment / Advance')))]));}
