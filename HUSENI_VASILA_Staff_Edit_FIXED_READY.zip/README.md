HUSENI VASILA final starter app.

Features: Admin/Worker login demo, Hajri Book P/A/H, Staff Entry, Site Entry, Material Entry, Payment Entry, Support, Video Upload placeholder, local storage.

Build: flutter pub get && flutter build apk --release

Important: live Worker-to-Admin sync and video upload require a cloud backend such as Firebase/Supabase. This starter intentionally does not include fake credentials.
